# Playwright Framework – Team Call Demo Script (Hinglish)

> **Total time:** ~40 min (35 min demo + 5 min Q&A)
> **Format:** Har section me → **Kya open karna hai** → **Kya bolna hai** → **Kya highlight karna hai**
> **Project folder:** `Playwright learn/playwright/`

---

## 0. Call se pehle ki tayyari (10 min pehle)

**Terminal 1 – app start karo (project root se):**
```bash
cd "/home/naveen_poptani/Desktop/Workspace/Playwright learn"
npm run db:seed      # optional: DB ko fresh seed data pe le aata hai (sara data reset ho jayega)
npm run dev          # backend :4000 + frontend :5173
```

**Terminal 2 – ek baar sab tests chala ke confirm karo:**
```bash
cd "/home/naveen_poptani/Desktop/Workspace/Playwright learn/playwright"
npm test             # 29 passed aana chahiye
```

**Checklist:**
- [ ] Browser me `http://localhost:5173` khul raha hai
- [ ] VS Code font size bada kar lo (`Ctrl +` 2-3 baar)
- [ ] Faltu tabs band kar do
- [ ] VS Code me sirf `playwright/` folder expand rakho
- [ ] Ye file (`DEMO_SCRIPT.md`) side me ya dusri screen pe khuli rakho

---

## 1. Introduction – Context set karo (2 min)

**Open:** Browser me `http://localhost:5173` (WorkFlow Manager app)

**Bolna hai:**
> "Hi team, aaj main aapko ek Playwright + TypeScript automation framework dikhaunga jo maine banaya hai.
> Ye app jo aap dekh rahe ho – **WorkFlow Manager** – ek employee management portal hai. Isme login, dashboard, employees ki list, add/edit/delete sab hai.
> Ise maine specially testing practice ke liye banaya hai – real auth hai (cookie based), real database hai.
>
> Framework ka goal simple hai: **ek hi framework me UI testing, API testing aur dono ko mila ke E2E testing** – aur wo bhi aise tarike se ki fast ho, parallel chale, aur scale ho sake."

**Highlight:** Quickly login karke dashboard aur employees list dikha do (30 sec). `test.user@example.com / Test@12345`

**Phir bolo:**
> "Aaj main 5 cheezein specially dikhaunga:"
> 1. Clean structure – core logic alag, app-specific code alag
> 2. Login sirf ek baar API se, session reuse – tests fast
> 3. API testing with custom checks – status, schema, response time
> 4. Test data API se banta hai aur test ke baad auto-delete
> 5. Tags – @smoke / @regression se specific tests chalana

---

## 2. Folder Structure – Point 1: Clean Structure (5 min)

**Open:** VS Code Explorer me `playwright/` folder, `src/` aur `tests/` expand karo

**Ye diagram screen pe dikhao / bolo:**
```
playwright/
├── src/
│   ├── config/      → settings: env, tags, timeouts (ek jagah sab)
│   ├── core/        → REUSABLE ENGINE – kisi bhi app ke liye kaam karega
│   │   ├── api/         ApiClient, ApiResponseWrapper
│   │   ├── ui/          BasePage, BaseComponent
│   │   ├── assertions/  custom API matchers
│   │   └── utils/       logger, step decorator, CleanupManager, schemaValidator
│   ├── api/         → APP-SPECIFIC: endpoints, services, models, JSON schemas
│   ├── pages/       → APP-SPECIFIC: LoginPage, DashboardPage, EmployeeDetailsPage
│   ├── data/        → test data factory + users.json
│   └── fixtures/    → sab ko jodta hai: base → api → data → ui
├── tests/
│   ├── setup/       → login ek baar
│   ├── api/         → pure API tests (browser nahi khulta)
│   ├── ui/          → browser tests
│   └── e2e/         → API + UI dono mila ke
├── env/             → environment wise URLs / credentials
└── playwright.config.ts
```

**Bolna hai:**
> "Is structure ka sabse important idea hai **separation**.
> `src/core` folder me jo code hai – BasePage, ApiClient, matchers, logger – usme WorkFlow Manager ka kahin naam nahi hai. Ye pure engine hai.
> Kal ko agar humein koi dusri app test karni hai, toh hum `core` folder as-it-is copy karenge, aur sirf `pages` aur `api` folder nayi app ke hisaab se likhenge.
>
> Aur tests folder bhi type ke hisaab se divide hai – setup, api, ui, e2e. Har ek Playwright ka alag 'project' hai, jo main config me dikhaunga."

**Highlight:** `src/core/` folder kholo aur bolo "dekho, yahan koi Employee ya Login ka word nahi hai".

---

## 3. Configuration (5 min)

### 3a. `playwright.config.ts`

**Open:** `playwright.config.ts`

**Line ~62 `projects:` pe jao. Bolna hai:**
> "Ye framework ka dil hai. Yahan 4 projects hain:"

| Project | Kya karta hai | Depends on |
|---|---|---|
| `setup` | Ek baar API se login karke session save karta hai | – |
| `api` | API tests, browser launch nahi hota | – |
| `ui` | Browser tests | `setup` |
| `e2e` | API + browser mixed tests | `setup` |

> "`dependencies: ['setup']` ka matlab – ui aur e2e tests chalne se pehle Playwright khud setup chalayega. Humein manually kuch nahi karna."

**Line ~42-60 `use:` block pe jao. Bolna hai:**
> "Ye har test ke default settings hain:
> - `baseURL` – isliye test me sirf `page.goto('/login')` likhte hain, poora URL nahi
> - `trace: 'retain-on-failure'`, `screenshot: 'only-on-failure'`, `video: 'retain-on-failure'` – **sirf fail hone pe** evidence save hota hai, toh disk nahi bharti
> - `retries` aur `workers` CI me alag, local me alag"

**Line ~14 `reporters` pe jao. Bolna hai:**
> "Reports 4 format me banti hain – terminal list, HTML, JUnit (Jenkins ke liye), JSON. CI me sharding ke liye blob report bhi support hai."

### 3b. `env/` + `src/config/env.config.ts`

**Open:** `src/config/env.config.ts`

**Bolna hai:**
> "Environment ki values yahan se aati hain. Order hai:
> 1. Real environment variable (CI secrets)
> 2. `env/.env.local` – mera local machine, git me commit nahi hota
> 3. `env/.env.qa` / `.env.staging` – environment wise
>
> Toh same tests, sirf `TEST_ENV=staging` laga ke staging pe chal jayenge. Aur agar koi variable missing hai toh clear error aata hai – `Missing env variable UI_BASE_URL`."

**Highlight:** `get user()` – "ye lazy getter hai, credentials tabhi padhe jaate hain jab koi test unhe maange".

### 3c. `src/config/timeouts.ts` + `tags.ts`

**Open:** `src/config/timeouts.ts`

**Bolna hai:**
> "Saare timeouts ek file me. Code me kahin bhi `5000` jaisa magic number nahi milega. Change karna ho toh ek jagah."

---

## 4. Point 2: Login ek baar API se, session reuse (5 min)

### 4a. Setup file

**Open:** `tests/setup/auth.setup.ts`

**Bolna hai:**
> "Normally log har test me login form fill karte hain – email type karo, password type karo, button click karo. 50 tests = 50 baar login. Slow bhi, flaky bhi.
>
> Yahan humne kya kiya – **sabse pehle sirf ek baar**, bina browser ke, API se login karte hain:"

```ts
await new AuthService(new ApiClient(request)).loginOrFail(config.user.email, config.user.password);
await request.storageState({ path: config.authFile });
```

> "Ye app httpOnly cookie `wf_token` use karti hai. Login ke baad wo cookie `.auth/user.json` file me save ho jaati hai. Phir har browser test is file ko load karta hai – matlab **browser khulte hi user already logged in hai**."

### 4b. Proof – Dashboard test

**Open:** `tests/ui/dashboard.ui.spec.ts`

**Bolna hai:**
> "Dekho is test me koi login step nahi hai. Seedha `/dashboard` khola aur check kiya ki 'Test' naam dikh raha hai. Ye kaam isliye karta hai kyunki setup ne session pehle hi de diya."

### 4c. Opposite case – Login tests

**Open:** `tests/ui/login.ui.spec.ts` (line 6)

```ts
test.use({ storageState: { cookies: [], origins: [] } });
```

> "Login page ke tests ko logged-out state chahiye, toh yahan ek line se saved session hata diya. Flexible hai – jahan chahiye wahan session, jahan nahi chahiye wahan nahi."

### 4d. API tests me bhi same idea

**Open:** `src/fixtures/api.fixture.ts` (line ~38, `apiSession`)

> "API tests ke liye bhi login **har worker me sirf ek baar** hota hai – `scope: 'worker'`. Agar 4 workers parallel chal rahe hain toh total 4 login, chahe 100 tests ho."

---

## 5. Point 3: API Testing with custom checks (7 min)

> **Flow:** ApiClient → Service → Custom Matchers → Test → Schema

### 5a. ApiClient – ek HTTP engine

**Open:** `src/core/api/ApiClient.ts`

**Bolna hai:**
> "Ye poore framework ka ek hi HTTP engine hai. Har API call isi se hoti hai. Ye automatically:
> - base URL lagata hai
> - time measure karta hai (`durationMs`)
> - log karta hai
> - **request aur response ko HTML report me attach karta hai** (line ~100 `attach`)
> - aur `maskSecrets` – password, token jaisi values report me `***` ban jaati hain
> - `failOnStatusCode: false` – 400/500 pe throw nahi karta, test khud status check karta hai"

### 5b. Service layer

**Open:** `src/api/services/EmployeeService.ts`

**Bolna hai:**
> "Test seedha URL nahi likhta. Service me business methods hain – `create`, `getById`, `update`, `delete`, `list`.
> Har method pe `@step()` decorator laga hai – isse report me readable step dikhta hai jaise `EmployeeService.create`.
> Aur `createOrFail` – precondition ke liye: banao aur agar fail hua toh turant clear error do."

**Open:** `src/api/endpoints.ts`
> "Saare URLs ek jagah. API path badla toh ek line change."

### 5c. Custom matchers – sabse important

**Open:** `src/core/assertions/api.matchers.ts`

**Bolna hai:**
> "Playwright ke `expect` ko humne extend kiya hai 4 naye checks ke saath:"

| Matcher | Kya check karta hai |
|---|---|
| `toHaveStatus(201)` | Status code. Fail hone pe **poora request/response** message me dikhata hai |
| `toMatchSchema('employee')` | Response JSON schema se match karta hai (Ajv library) |
| `toHaveField('data.email', x)` | Nested field ki value – dot path se |
| `toRespondWithin(3000)` | Response time limit |

> "Iska fayda – test me baar baar `JSON.parse`, `response.status()`, manual loops nahi likhne padte. **Kam code, saaf test.**"

### 5d. Actual test

**Open:** `tests/api/employees.api.spec.ts` – pehla test `creates an employee`

```ts
await expect(response).toHaveStatus(201);
await expect(response).toMatchSchema('employee');
await expect(response).toRespondWithin(3_000);
```

> "Dekho test kitna readable hai – lagbhag English jaisa."

**Neeche scroll karke `validation & access` block dikhao:**
> "Negative cases bhi hain – empty body (400), galat department ka role (400), state-city mismatch (400), duplicate email (409), bina login (401), aur viewer user create nahi kar sakta (403). Ye role-based access bhi check ho raha hai."

### 5e. Schema file

**Open:** `src/api/schemas/employee.schema.json`
> "Ye contract hai – response me kaunse fields hone chahiye, kis type ke. Agar backend developer galti se koi field hata de ya type badal de, toh ye test turant pakad lega."

### 5f. Data-driven test

**Open:** `tests/api/auth.api.spec.ts` (line ~26 `for` loop) + `src/data/users.json`
> "Invalid login cases JSON file se aate hain. Naya case add karna ho toh sirf JSON me ek row – code change nahi."

---

## 6. Point 4: Test data API se banao, auto-delete (5 min)

> **Flow:** DataFactory → data.fixture → CleanupManager → E2E test

### 6a. DataFactory

**Open:** `src/data/dataFactory.ts`

**Bolna hai:**
> "Har baar naya, unique employee banta hai – Faker library se realistic naam, aur email me timestamp (`auto.<timestamp>@workflow.test`), employee code random 6-digit.
> Isliye agar 4 tests parallel chal rahe hain, kabhi clash nahi hoga – 'email already exists' jaisa error nahi aayega."

### 6b. Data fixture

**Open:** `src/fixtures/data.fixture.ts`

**Bolna hai:**
> "Ye fixture test ko employee ready-made deta hai. Line ~21 dekho:"

```ts
cleanup.add(`delete employee ${employee.employeeCode}`, () => seedApi.employees.delete(employee.id));
```

> "Employee banate hi uska delete register ho jaata hai. Test pass ho ya fail – test ke baad delete **zaroor** chalega."

### 6c. CleanupManager

**Open:** `src/core/utils/CleanupManager.ts`
> "Ye cleanup ki list rakhta hai aur test ke baad **reverse order** me chalata hai. Agar ek cleanup fail ho jaye toh baaki rukte nahi – sirf warning log hoti hai."

### 6d. E2E test – sab ek saath

**Open:** `tests/e2e/employee-lifecycle.e2e.spec.ts`

**Bolna hai:**
> "Ye hybrid testing hai:
> - **Test 1:** employee API se banaya (fast, 100ms) → browser me uska page khola → naam aur code check kiya
> - **Test 2:** API se banaya → browser se Delete button click kiya → API se confirm kiya ki ab 404 aa raha hai
>
> UI me sirf wo kaam karte hain jo user karta hai. Setup aur verification API se – isliye fast aur stable."

> "Proof: tests chalne se pehle DB me 25 employees the, sab tests ke baad bhi 25. Koi kachra data nahi bachta."

---

## 7. Point 5: Tags (2 min)

**Open:** `src/config/tags.ts`

**Bolna hai:**
> "Tags constants me hain – taaki koi `@smok` jaisa typo na kare."

**Open:** kisi bhi test me `{ tag: [Tag.smoke, Tag.regression] }` dikhao

**Terminal me chala ke dikhao:**
```bash
npm run test:smoke                       # sirf @smoke (7 tests)
npx playwright test --grep @negative     # sirf negative (16 tests)
npm run test:regression                  # 22 tests
```

> "CI me bhi env variable se: `TAGS="@smoke" EXCLUDE_TAGS="@negative" npm test`. Jaise PR pe sirf smoke, nightly pe full regression."

---

## 8. Page Objects + Fixtures (3 min)

### 8a. BasePage + LoginPage

**Open:** `src/core/ui/BasePage.ts` → phir `src/pages/LoginPage.ts`

**Bolna hai:**
> "BasePage me common actions hain – click, fill, expectVisible, expectText. Koi hard wait (`waitForTimeout`) nahi – sab Playwright ka auto-wait.
> LoginPage sirf batata hai **kya hai screen pe** – locators. Aur locators role/label se hain – `getByRole('button', { name: 'Log in' })` – CSS class se nahi. Isliye UI ka design badle toh bhi test nahi tootega."

### 8b. Fixture chain

**Open:** `src/fixtures/index.ts`

```
baseTest (cleanup, logging)
  → apiTest (api, guestApi, seedApi)
    → dataTest (createEmployee, existingEmployee)
      → uiTest (loginPage, dashboardPage, employeeDetailsPage)
```

> "Har test bas ek line import karta hai: `import { test, expect } from '@fixtures/index'`.
> Aur test me `async ({ loginPage, existingEmployee, api })` likho – sab ready mil jaata hai. Test me `new LoginPage(page)` likhne ki zarurat nahi.
> Fixtures lazy hain – API test me browser launch hi nahi hota."

---

## 9. 🎬 LIVE DEMO – UI Mode (8 min)

**Terminal 2:**
```bash
cd "/home/naveen_poptani/Desktop/Workspace/Playwright learn/playwright"
npm run test:ui-mode
```

**Step by step:**

1. **Left side projects dikhao** – setup, api, ui, e2e
   > "Ye wahi 4 projects hain jo config me the."

2. **Sirf `setup` run karo** (▶ button)
   > "Dekho, ek second me login ho gaya." → VS Code me `.auth/user.json` dikhao – cookie save hai.

3. **Sab run karo** (top ▶)
   > "29 tests, parallel – ~15 second."

4. **Filter box me `@smoke` type karo** → phir `@negative`
   > "Tags se instantly filter."

5. **Koi API test click karo** (e.g. `creates an employee`) → **Attachments** tab
   > "Request aur response report me – aur password `***` me hidden hai." (auth test me dikhega)

6. **E2E delete test click karo** → **timeline / actions** dikhao
   > "Har step ka before/after DOM snapshot. Upar `EmployeeService.create`, `EmployeeDetailsPage.deleteEmployee` jaise readable steps – ye `@step` decorator ki wajah se."
   → **Network** tab me `/api/employees` call dikhao

7. **Pick locator** button → login button pe hover karo
   > "Locator dhundhna bahut aasaan."

8. **Watch mode (👁 icon) ON karo** → live test todo:
   - `tests/ui/login.ui.spec.ts` me `'Invalid email or password'` ko `'Wrong text'` kar do → save
   - Test fail hoga → error + screenshot dikhao
   > "Fail hone pe exact pata chalta hai kya expected tha, kya mila."
   - Wapas theek karo → save → green ✅

---

## 10. Code Quality + Reports (2 min)

**Terminal:**
```bash
npm run quality    # typecheck + lint + prettier
npm run report     # HTML report browser me
```

**Bolna hai:**
> "`npm run quality` ek command me TypeScript check, ESLint aur formatting check karta hai.
> ESLint me Playwright rules hain jo `waitForTimeout`, `test.only`, `page.pause` jaise galtiyan **error** bana dete hain – taaki koi galti se commit na kare."

**Open:** `eslint.config.mjs` (sirf 2 sec dikhao)

**HTML report me** – ek failed/passed test kholo, steps aur attachments dikhao.

---

## 11. Wrap-up + Next steps (1 min)

**Bolna hai:**
> "Summary:
> 1. ✅ Clean structure – core reusable, app code alag
> 2. ✅ Login ek baar API se – tests fast
> 3. ✅ API tests with status / schema / response time checks
> 4. ✅ Test data API se, auto cleanup – parallel safe
> 5. ✅ Tags se selective run
>
> **Next steps:** Employees list page, Add-employee wizard ke page objects, aur CI pipeline (GitHub Actions / Jenkins) me lagana."

---

## 12. Q&A – Possible sawaal aur jawab

| Sawaal | Jawab |
|---|---|
| **Cypress/Selenium kyun nahi?** | Playwright me API + UI ek hi tool me, auto-wait, parallel free me, multiple browsers, trace viewer. |
| **Agar backend down ho?** | Setup project hi fail ho jayega, toh ui/e2e chalenge hi nahi – time waste nahi hoga. |
| **Test data DB me reh jaye toh?** | Cleanup pass/fail dono me chalta hai. Phir bhi `npm run db:seed` se DB reset ho sakta hai. |
| **Naya page add kaise karein?** | `src/pages/` me class banao jo `BasePage` extend kare → `ui.fixture.ts` me add karo → `pages/index.ts` me export. |
| **Nayi API kaise add karein?** | `endpoints.ts` me URL → `services/` me class → `api.fixture.ts` ke `buildServices` me add. |
| **Session expire ho jaye toh?** | Har run me setup naya login karta hai, toh hamesha fresh session. |
| **Firefox pe chalega?** | Haan – `CROSS_BROWSER=true npx playwright test --project=ui-firefox` |
| **Staging pe kaise chalayein?** | `env/.env.staging` banao → `TEST_ENV=staging npm test` |
| **Parallel me clash kyun nahi hota?** | Har test ka data unique (timestamp email + random code), aur har test apna data khud delete karta hai. |
| **Viewer vs Admin?** | API test `forbids a viewer from creating employees` – viewer ko 403 milta hai. |

---

## 13. Agar demo me kuch gadbad ho (Troubleshooting)

| Problem | Fix |
|---|---|
| `Missing env variable "UI_BASE_URL"` | `env/.env.local` file check karo |
| Sab tests fail, `ECONNREFUSED` | App nahi chal rahi → root me `npm run dev` |
| Login tests fail | Password badla hoga → root me `npm run db:seed` |
| UI mode khul nahi raha | Terminal me `playwright/` folder me ho ya nahi check karo |
| VS Code me red errors, terminal me pass | `Ctrl+Shift+P` → "TypeScript: Restart TS Server" |

---

## Quick Reference – Files ka order (cheat sheet)

| # | Section | File |
|---|---|---|
| 1 | Intro | Browser: `localhost:5173` |
| 2 | Structure | Explorer: `src/`, `tests/` |
| 3 | Config | `playwright.config.ts` → `src/config/env.config.ts` → `src/config/timeouts.ts` |
| 4 | Login once | `tests/setup/auth.setup.ts` → `tests/ui/dashboard.ui.spec.ts` → `tests/ui/login.ui.spec.ts` → `src/fixtures/api.fixture.ts` |
| 5 | API testing | `src/core/api/ApiClient.ts` → `src/api/services/EmployeeService.ts` → `src/api/endpoints.ts` → `src/core/assertions/api.matchers.ts` → `tests/api/employees.api.spec.ts` → `src/api/schemas/employee.schema.json` → `tests/api/auth.api.spec.ts` + `src/data/users.json` |
| 6 | Test data | `src/data/dataFactory.ts` → `src/fixtures/data.fixture.ts` → `src/core/utils/CleanupManager.ts` → `tests/e2e/employee-lifecycle.e2e.spec.ts` |
| 7 | Tags | `src/config/tags.ts` → terminal |
| 8 | POM + Fixtures | `src/core/ui/BasePage.ts` → `src/pages/LoginPage.ts` → `src/fixtures/index.ts` |
| 9 | Live demo | `npm run test:ui-mode` |
| 10 | Quality | `npm run quality` → `eslint.config.mjs` → `npm run report` |
| 11 | Wrap-up | – |

**All the best for the call! 🚀**
